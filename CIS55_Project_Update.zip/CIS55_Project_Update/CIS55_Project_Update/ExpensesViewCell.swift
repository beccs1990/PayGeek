//
//  ExpensesViewCell.swift
//  CIS55_Project_Update
//
//  Created by profile on 3/2/16.
//  Copyright © 2016 DeAnza. All rights reserved.
//

import UIKit

class ExpensesViewCell: UICollectionViewCell {
    
    @IBOutlet var recentPurchases: UILabel!
    @IBOutlet var recent1name: UILabel!
    @IBOutlet var recent2name: UILabel!
    @IBOutlet var recent3name: UILabel!
}
