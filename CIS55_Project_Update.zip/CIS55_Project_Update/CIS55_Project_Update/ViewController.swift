//
//  ViewController.swift
//  CIS55_Project_Update
//
//  Created by profile on 3/2/16.
//  Copyright © 2016 DeAnza. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {

    let collectionViewA = IncomeViewCell()
    let collectionViewB = ExpensesViewCell()
    var tableData: [String] = ["Evo X", "458", "GTR", "Evo X", "458", "GTR", "Evo X", "458", "GTR", "Evo X", "458", "GTR"]
    var tablePay: [String] = ["Evo X", "458", "GTR", "Evo X", "458", "GTR", "Evo X", "458", "GTR", "Evo X", "458", "GTR"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == collectionViewA
        {
            return 1
        } else {
            return 1
        }
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        if collectionView == collectionViewA
        {
        let cellIncome: IncomeViewCell = collectionView.dequeueReusableCellWithReuseIdentifier("incomeOverview", forIndexPath: indexPath) as! IncomeViewCell
        cellIncome.incomeName.text = tableData[indexPath.row]
        cellIncome.incomeAmt.text = tablePay[indexPath.row]
        cellIncome.salaryName.text = tableData[indexPath.row]
        cellIncome.salaryAmt.text = tablePay[indexPath.row]
        return cellIncome
        } else {
            let cellExpenses: ExpensesViewCell = collectionView.dequeueReusableCellWithReuseIdentifier("expensesOverview", forIndexPath: indexPath) as! ExpensesViewCell
            cellExpenses.recentPurchases.text = tableData[indexPath.row]
            return cellExpenses
        }
    }
    
    func collectionView(collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, AtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell: ExpensesViewCell = collectionView.dequeueReusableCellWithReuseIdentifier("expensesOverview", forIndexPath: indexPath) as! ExpensesViewCell
        return cell
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

