//
//  IncomeViewCell.swift
//  CIS55_Project_Update
//
//  Created by profile on 3/2/16.
//  Copyright © 2016 DeAnza. All rights reserved.
//

import UIKit

class IncomeViewCell: UICollectionViewCell {
    
    @IBOutlet var incomeName: UILabel!
    @IBOutlet var incomeAmt: UILabel!
    @IBOutlet var salaryName: UILabel!
    @IBOutlet var salaryAmt: UILabel!

}
